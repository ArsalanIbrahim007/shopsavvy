// background.js — the extension's service worker: asks the ShopSavvy API which product a store page is, and shows the answer on
// the toolbar badge.
//
// The content script reads {url, title, price} from the page (reader.js) and sends it here. Calls go from here, not from the
// page: an extension page with a host permission for the API is not held back by CORS, the store's page is.
// A Manifest V3 service worker is stopped when idle and loses its variables, so each tab's answer is kept in
// chrome.storage.session, where the popup reads it.

importScripts("format.js"); // ShopSavvyFormat.badgeSaving

// The deployed API: since 2026-11-13 it runs on the team's PC behind an ngrok tunnel (deploy/README-pc.md, deploy/ngrok-domain.txt).
// The popup's settings can point it at a local one (http://localhost:5000) for development.
const DEFAULT_API = "https://cranium-espresso-sway.ngrok-free.dev";
const BADGE = { save: "#d97706", best: "#059669" };

// ngrok's free tunnel answers a browser's request with an HTML warning page unless it carries this header (checked 2026-11-18: text/html
// without it, the API's JSON with it). The website sends it too (frontend/src/api/client.js).
const apiHeaders = (base) => (/\.ngrok(-free)?\.(app|dev|io)\b/i.test(base) ? { "ngrok-skip-browser-warning": "1" } : undefined);

// The website's own address is not the API (2026-11-19: "https://shopsavvy.pages.dev" saved in Settings, and every page said
// "Cannot reach ShopSavvy"): a saved website address means the deployed API.
const WEBSITE_HOSTS = /(^|\.)(shopsavvy\.pages\.dev|pages\.dev)$/i;
async function apiBase() {
  const { apiBase: saved } = await chrome.storage.sync.get("apiBase");
  const base = String(saved || DEFAULT_API).replace(/\/+$/, "");
  try {
    if (WEBSITE_HOSTS.test(new URL(base).hostname)) return DEFAULT_API;
  } catch {
    return DEFAULT_API;
  }
  return base;
}

// The website the answers link to: the deployed one, or the local one beside a local API (the Vite dev server's port).
async function siteBase() {
  const base = await apiBase();
  return /\/\/(localhost|127\.0\.0\.1)(:\d+)?$/.test(base) ? base.replace(/:\d+$/, ":5173") : "https://shopsavvy.pages.dev";
}

/**
 * A shop abroad (Amazon): its price is in another currency, so the product's NAME is searched for, and the closest product's offers
 * in Pakistan come back in the shape of a /match answer (found, offers, cheapest, productUrl), marked lookup: true.
 */
async function lookup(product) {
  const base = await apiBase();
  const site = await siteBase();
  const query = ShopSavvyFormat.lookupQuery(product.title);
  const searchUrl = `${site}/results?q=${encodeURIComponent(query)}`;
  if (!query) return { found: false, lookup: true, searchUrl };
  try {
    const res = await fetch(`${base}/api/listings/search?q=${encodeURIComponent(query)}`, { headers: apiHeaders(base), signal: AbortSignal.timeout(20000) });
    if (res.status === 429) return { error: "busy" };
    if (!res.ok) return { error: "failed", status: res.status };
    const body = await res.json();
    // A search that only found names spelt nearly the same is not this product.
    const group = body.matchedBy === "spelling" ? null : body.groups?.[0];
    const offers = (group?.offers ?? [])
      .filter((o) => o.price > 0)
      .sort((a, b) => a.price - b.price)
      .map((o) => ({ id: o._id, platform: o.platform, price: o.price, url: o.productUrl || o.sourceUrl, condition: o.condition || "new", inStock: o.inStock !== false }));
    if (offers.length === 0) return { found: false, lookup: true, reason: "not_stored", searchUrl };
    const cheapest = offers.find((o) => o.condition === "new") ?? offers[0];
    return {
      found: true, lookup: true, query, productName: group.productName, offers,
      cheapest: { ...cheapest, cheaperThanThisPage: false },
      productUrl: `${site}/product/${cheapest.id}`, searchUrl,
    };
  } catch {
    return { error: "offline", base };
  }
}

// The API builds the links to the website from its PUBLIC_SITE_URL setting, and without it they point at the developer's
// http://localhost:5173 ("Search for it on ShopSavvy" opened it on 2026-11-19). From a deployed API, such a link is the website's.
const LOCAL_SITE = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?/i;
async function withSiteLinks(result, base) {
  if (!result || LOCAL_SITE.test(base)) return result;
  const site = await siteBase();
  const fix = (url) => (typeof url === "string" ? url.replace(LOCAL_SITE, site) : url);
  return { ...result, productUrl: fix(result.productUrl), searchUrl: fix(result.searchUrl) };
}

async function match(product) {
  const base = await apiBase();
  const params = new URLSearchParams({ url: product.url });
  if (product.title) params.set("title", product.title);
  if (product.price) params.set("price", String(product.price));
  try {
    const res = await fetch(`${base}/api/listings/match?${params}`, { headers: apiHeaders(base), signal: AbortSignal.timeout(20000) });
    if (res.status === 429) return { error: "busy" };
    if (!res.ok) return { error: "failed", status: res.status };
    return withSiteLinks(await res.json(), base);
  } catch {
    return { error: "offline", base };
  }
}

function setBadge(tabId, result) {
  let text = "";
  let color = BADGE.best;
  if (result?.found && result.cheapest?.cheaperThanThisPage) {
    text = ShopSavvyFormat.badgeSaving(result.cheapest.saving);
    color = BADGE.save;
  } else if (result?.found && result.lookup) {
    text = "PK";
  } else if (result?.found && result.offers?.length) {
    text = "✓";
  }
  chrome.action.setBadgeText({ tabId, text });
  if (text) chrome.action.setBadgeBackgroundColor({ tabId, color });
}

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  const tabId = sender.tab?.id;
  if (tabId === undefined) return false;

  if (message.type === "CLEAR") {
    chrome.storage.session.remove(`tab:${tabId}`);
    chrome.action.setBadgeText({ tabId, text: "" });
    return false;
  }

  if (message.type === "MATCH" || message.type === "LOOKUP") {
    chrome.storage.session.set({ [`tab:${tabId}`]: { product: message.product, result: null, at: Date.now() } });
    (message.type === "LOOKUP" ? lookup(message.product) : match(message.product)).then(async (result) => {
      await chrome.storage.session.set({ [`tab:${tabId}`]: { product: message.product, result, at: Date.now() } });
      setBadge(tabId, result);
      sendResponse({ result });
    });
    return true; // answered later, once the API has
  }
  return false;
});

chrome.tabs.onRemoved.addListener((tabId) => chrome.storage.session.remove(`tab:${tabId}`));
